package p1;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import p1.EmailT1;

public class SendEmailT1 {
	

	@Test
	public void sendEmail() throws Exception {
		String userName = ""; // 发件人邮箱
		String password = ""; // 发件人密码
		String smtpHost = ""; // 邮件服务器
 
		String to = ""; // 收件人，多个收件人以半角逗号分隔
		String cc = ""; // 抄送，多个抄送以半角逗号分隔
		String subject = "这是邮件的主题"; // 主题
		String body = "这是邮件的正文"; // 正文，可以用html格式的哟
		List<String> attachments = Arrays.asList("D:\\test1.jpg", "D:\\test2.jpg"); // 附件的路径，多个附件也不怕
 
		EmailT1 email = EmailT1.entity(smtpHost, userName, password, to, cc, subject, body, attachments);
 
		email.send(); // 发送！
	}

}
